## Day 02 - Quick Tasks

### What to Do

1. **Watch the Day 01 video** and take notes.
2. **Write a short blog** (500-800 words) about what you learned.
    - Include your own diagrams and code examples.
    - Embed the video in your blog.
3. **Share your blog** on LinkedIn and Twitter/X with `#30daysofawsterraform`.
    - Tag **Piyush Sachdeva**.
4. **Submit your work** (see `submission.md` for instructions) .

---

### Tips

- Keep it simple and clear.
- Feel free to take AI assistance, but do not overuse it.
- Use your own diagrams.
- Engage with others’ posts.

---

Good luck! 🚀
