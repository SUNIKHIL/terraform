# Day 09 - Quick Tasks

## What to Do

- [ ] Watch the Day 09 video and take notes
- [ ] Write a short blog (500-800 words) about what you learned
  - Include your own diagrams and code examples
  - Embed the video
- [ ] Share your blog on LinkedIn and Twitter/X with **#30daysofawsterraform**
- [ ] Tag me (Piyush Sachdeva)
- [ ] Submit your work (see `submission.md` for how)

## Tips

- Keep it simple and clear, feel free to take AI assistance but do not overuse it
- Use your own diagrams
- Engage with others’ posts

Good luck! 🚀
