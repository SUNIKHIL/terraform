# Adityapradhan14 - 30 Days Terraform & AWS Challenge

**Participant:** @Adityapradhan14  
**Start Date:** 2025-11-24  
**Challenge Repository:** [terraform-aws-30days](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws)  
**Personal Practice Repo:** https://github.com/Adityapradhan14/aws-terraform-30days.git

## Progress Overview
- **Days Completed:** 1/30
- **Current Streak:** 1 day
- **Last Submission:** 2025-11-24

---

## Day 1: Introduction to Terraform
**Date:** 2025-11-24  
**Status:** ✅ Completed

### 📝 Blog Post
[Day 1 - Introduction to Terraform](https://hashnode.com/post/cmid4hs0c000f02jy0hiofewd)

### 🔗 Links
- **Social Media:** [Post](https://x.com/adi_pradhan14/status/1992939383780221056?s=20)
- **Code Repository:** [GitHub](https://github.com/Adityapradhan14/aws-terraform-30days.git)
- **Issue:** [#15](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws/issues/15)

### 🎯 Key Learnings

Concept of Iac
Terraform and its features
Workflow of terraform
Terraform installation

---

