# Akshaysrajan - 30 Days Terraform & AWS Challenge

**Participant:** @Akshaysrajan  
**Start Date:** 2025-11-24  
**Challenge Repository:** [terraform-aws-30days](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws)  
**Personal Practice Repo:** https://github.com/Akshaysrajan/Terraform-Full-Course-Aws

## Progress Overview
- **Days Completed:** 1/30
- **Current Streak:** 1 day
- **Last Submission:** 2025-11-24

---

## Day 1: Intro To IAC
**Date:** 2025-11-24  
**Status:** ✅ Completed

### 📝 Blog Post
[Day 1 - Intro To IAC](https://akshay.notion.site/DAY-1-2b510cab0918801184e4fff335d3b5ec?source=copy_link)

### 🔗 Links
- **Social Media:** [Post](https://x.com/akshaysrajan/status/1993025454358556673?s=20)
- **Code Repository:** [GitHub](https://github.com/Akshaysrajan/Terraform-Full-Course-Aws)
- **Issue:** [#38](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws/issues/38)

### 🎯 Key Learnings

Learnings are shared in the blog in detail
https://akshay.notion.site/DAY-1-2b510cab0918801184e4fff335d3b5ec?source=copy_link

---

