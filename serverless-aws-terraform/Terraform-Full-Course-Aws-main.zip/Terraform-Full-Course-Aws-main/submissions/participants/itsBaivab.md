# itsBaivab - 30 Days Terraform & AWS Challenge

**Participant:** @itsBaivab  
**Start Date:** 2025-07-16  
**Challenge Repository:** [terraform-aws-30days](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws)  
**Personal Practice Repo:** https://github.com/Souradip121/Fireducks-Blogation

## Progress Overview
- **Days Completed:** 2/30
- **Current Streak:** 1 day
- **Last Submission:** 2025-07-16

---

## Day 13: VPC createion wtih ec2 instances
**Date:** 2025-07-16  
**Status:** ✅ Completed

### 📝 Blog Post
[Day 13 - VPC createion wtih ec2 instances](https://medium.com/thecloudopscommunity/setting-up-a-highly-available-kubernetes-cluster-with-multiple-masters-and-a-load-balancer-a1e7df61be5d)

### 🔗 Links
- **Social Media:** [Post](https://www.linkedin.com/posts/renascence-dey-b422642b9_gssoc2025-girlscript-projectadmin-activity-7351341098046324736-1vM_?utm_source=share&utm_medium=member_desktop&rcm=ACoAAD2vhDEBo85a4B0CVY4uZvJUMvVcuj8UHNk)
- **Code Repository:** [GitHub](https://github.com/Souradip121/Fireducks-Blogation)
- **Issue:** [#6](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws/issues/6)

### 🎯 Key Learnings

It was a very insightful session.

---

## Day 44: fasdf
**Date:** 2025-07-16  
**Status:** ✅ Completed

### 📝 Blog Post
[Day 44 - fasdf](fasdf)

### 🔗 Links
- **Social Media:** [Post](fasdfas)
- **Code Repository:** [GitHub](fasdf)
- **Issue:** [#7](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws/issues/7)

### 🎯 Key Learnings

fasdfads

---

