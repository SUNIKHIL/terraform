# medashabari - 30 Days Terraform & AWS Challenge

**Participant:** @medashabari  
**Start Date:** 2025-11-25  
**Challenge Repository:** [terraform-aws-30days](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws)  
**Personal Practice Repo:** https://github.com/medashabari/terraform-aws-complete/tree/main/day1

## Progress Overview
- **Days Completed:** 5/30
- **Current Streak:** 2 days
- **Last Submission:** 2025-11-29

---

## Day 1: Day 1 task
**Date:** 2025-11-25  
**Status:** ✅ Completed

### 📝 Blog Post
[Day 1 - Day 1 task](https://medium.com/@shabarimeda/what-is-infrastructure-as-code-iac-7630812cecf6)

### 🔗 Links
- **Social Media:** [Post](https://www.linkedin.com/posts/shabarish-meda_30daysofawsterraform-terraform-aws-activity-7398950392941707264-K0Hj?utm_source=social_share_send&utm_medium=member_desktop_web&rcm=ACoAAD3PQ5gBrzRUsYrFvDAHTj93UBwyIwLTeYs)
- **Code Repository:** [GitHub](https://github.com/medashabari/terraform-aws-complete/tree/main/day1)
- **Issue:** [#46](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws/issues/46)

### 🎯 Key Learnings

What I learned today:
 • What Infrastructure as Code (IaC) really means
 • Why Terraform is one of the most powerful IaC tools
 • Terraform’s core workflow: Write → Init → Plan → Apply
 • Setting up Terraform locally
 • Configuring AWS CLI & IAM user credentials
 • Creating the first Terraform configuration block (provider block)

<img width=3475 height=326 alt=Image src=https://github.com/user-attachments/assets/6c486204-6b60-4d93-a92c-88587b9318fc />

---

## Day 2: Understanding Providers
**Date:** 2025-11-26  
**Status:** ✅ Completed

### 📝 Blog Post
[Day 2 - Understanding Providers](https://medium.com/@shabarimeda/understanding-terraform-providers-the-bridge-between-your-code-and-the-cloud-8c741ec185a7)

### 🔗 Links
- **Social Media:** [Post](https://www.linkedin.com/posts/shabarish-meda_30daysofawsterraform-terraform-cloudcomputing-share-7399317609697030145-ojJm?utm_source=share&utm_medium=member_desktop&rcm=ACoAAD3PQ5gBrzRUsYrFvDAHTj93UBwyIwLTeYs)
- **Code Repository:** [GitHub](https://github.com/medashabari/terraform-aws-complete/tree/main/day2)
- **Issue:** [#91](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws/issues/91)

### 🎯 Key Learnings

- What providers are and why they matter
- The difference between Terraform core and provider versions
- Why versioning is critical for stability, security, and reproducibility

---

## Day 4: S3 Remote backend
**Date:** 2025-11-30  
**Status:** ✅ Completed

### 📝 Blog Post
[Day 4 - S3 Remote backend](https://medium.com/@shabarimeda/terraform-state-file-management-remote-backend-s3-native-locking-add2bbed58fc)

### 🔗 Links
- **Social Media:** [Post](https://www.linkedin.com/posts/shabarish-meda_terraform-state-file-management-remote-share-7400900173129949184-SDyQ?utm_source=share&utm_medium=member_desktop&rcm=ACoAAD3PQ5gBrzRUsYrFvDAHTj93UBwyIwLTeYs)
- **Code Repository:** [GitHub](https://github.com/medashabari/terraform-aws-complete/tree/main/day4)
- **Issue:** [#278](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws/issues/278)

### 🎯 Key Learnings

 What the Terraform state file actually contains
• Why you should never edit the state file manually
• Best practices for securing and organizing state
• Setting up a remote backend using AWS S3
• Terraform 1.10+ now supports native S3 state locking (no DynamoDB needed!)
• How state locking prevents conflicts in collaborative/team environments
• Testing lock behavior by running concurrent Terraform operations

---

## Day 5: Terraform variables
**Date:** 2025-12-01  
**Status:** ✅ Completed

### 📝 Blog Post
[Day 5 - Terraform variables](https://medium.com/@shabarimeda/terraform-variables-input-local-output-precedence-deep-dive-2a9a9c83ecb2)

### 🔗 Links
- **Social Media:** [Post](https://www.linkedin.com/posts/shabarish-meda_terraform-aws-devops-share-7401138342588784640-mefa?utm_source=share&utm_medium=member_desktop&rcm=ACoAAD3PQ5gBrzRUsYrFvDAHTj93UBwyIwLTeYs)
- **Code Repository:** [GitHub](https://github.com/medashabari/terraform-aws-complete/tree/main/day5)
- **Issue:** [#300](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws/issues/300)

### 🎯 Key Learnings

- Input variables → Accept values from users, files, CLI, or automation
- Local variables → Compute and reuse internal values
- Output variables → Expose useful information after deployment
- Variable precedence → CLI > auto.tfvars > tfvars > environment variables > defaults > prompt

<img width=1881 height=3344 alt=Image src=https://github.com/user-attachments/assets/b9d6f3e1-beef-4595-8ed6-995911eb0c3b />

---

## Day 3: S3 - VPC implicit dependency
**Date:** 2025-11-29  
**Status:** ✅ Completed

### 📝 Blog Post
[Day 3 - S3 - VPC implicit dependency](https://medium.com/@shabarimeda/understanding-aws-authentication-for-terraform-0e0dc3a0ba17)

### 🔗 Links
- **Social Media:** [Post](https://www.linkedin.com/posts/shabarish-meda_30daysofawsterraform-30daysofawsterraform-share-7400576369824395264-SDOo?utm_source=share&utm_medium=member_desktop&rcm=ACoAAD3PQ5gBrzRUsYrFvDAHTj93UBwyIwLTeYs)
- **Code Repository:** [GitHub](https://github.com/medashabari/terraform-aws-complete/tree/main/day3)
- **Issue:** [#251](https://github.com/piyushsachdeva/Terraform-Full-Course-Aws/issues/251)

### 🎯 Key Learnings

How AWS authentication works

 • AWS CLI setup (aws configure)

 • Environment variables for AWS access

 • Using IAM roles for secure deployments

 • Creating an S3 bucket with Terraform

 • **Difference between implicit and explicit dependency**

---

